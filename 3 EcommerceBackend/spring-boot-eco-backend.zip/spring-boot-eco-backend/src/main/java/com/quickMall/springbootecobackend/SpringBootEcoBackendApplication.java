package com.quickMall.springbootecobackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEcoBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEcoBackendApplication.class, args);
	}

}
