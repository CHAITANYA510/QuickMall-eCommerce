package com.quickMall.springbootecobackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEcoBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
