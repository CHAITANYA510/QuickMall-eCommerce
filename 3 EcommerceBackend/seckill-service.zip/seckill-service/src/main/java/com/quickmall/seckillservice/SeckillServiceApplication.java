package com.quickmall.seckillservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeckillServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeckillServiceApplication.class, args);
	}

}
