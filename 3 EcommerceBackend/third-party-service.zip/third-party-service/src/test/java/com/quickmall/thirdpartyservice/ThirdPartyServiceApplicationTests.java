package com.quickmall.thirdpartyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThirdPartyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
