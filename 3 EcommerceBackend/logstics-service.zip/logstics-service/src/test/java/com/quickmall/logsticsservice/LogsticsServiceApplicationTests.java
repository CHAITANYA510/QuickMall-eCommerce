package com.quickmall.logsticsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogsticsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
