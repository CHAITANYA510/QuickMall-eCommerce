package com.quickmall.logsticsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogsticsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogsticsServiceApplication.class, args);
	}

}
